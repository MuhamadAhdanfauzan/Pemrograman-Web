// Fungsi untuk memuat produk dari API
function loadProducts() {
  // Ganti URL dengan endpoint API yang benar
  fetch('http://localhost:8000/api/product')
    .then(response => response.json())  // Menangani respons JSON
    .then(data => {
      const productList = document.getElementById('product-list');
      productList.innerHTML = ''; // Clear the existing product list

      // Periksa apakah data yang diterima ada
      if (data && data.data && Array.isArray(data.data)) {
        // Loop untuk menampilkan produk
        data.data.forEach(product => {
          const productCard = document.createElement('div');
          productCard.classList.add('country__card');

          // Menggunakan path relatif ke folder 'uploads', dengan nama file gambar dari kolom 'image'
          const imageUrl = product.image ? `uploads/${product.image}` : 'assets/default.jpg'; // Gunakan gambar default jika tidak ada

          productCard.innerHTML = `
            <img src="${imageUrl}" alt="${product.product_name}" class="product-image" />
            <div class="country__name">
              <span>${product.product_name}</span>
            </div>
            <p class="price">Rp ${product.price}</p>
          `;

          productList.appendChild(productCard);
        });
      } else {
        productList.innerHTML = '<p>No products available.</p>';
      }
    })
    .catch(error => {
      console.error('Error:', error);
      const productList = document.getElementById('product-list');
      productList.innerHTML = '<p>Terjadi kesalahan saat memuat produk.</p>';
    });
}

// Panggil fungsi loadProducts() saat halaman dimuat
document.addEventListener('DOMContentLoaded', loadProducts);
